

>هذا البوت بلغه العربيه فقط

[![invite bot](https://cdn.discordapp.com/attachments/462283949087916033/521407515741650954/1.jpg)](https://premiumbot.netlify.com)

[![server support](https://cdn.discordapp.com/attachments/462283949087916033/521407531390730240/2.jpg)](https://discord.gg/mkseyYy)

[![Open Source](https://cdn.discordapp.com/attachments/462283949087916033/521407545944965124/3.jpg)](https://github.com/n3k4a2018/Premiumbot)

[![Commands](https://cdn.discordapp.com/attachments/462283949087916033/521407565305872409/4.jpg)](https://hastebin.com/tisinaqubo.coffeescript)

>#Preimum bot open soruce by @ᵀᴳ n3k4a#0533  
